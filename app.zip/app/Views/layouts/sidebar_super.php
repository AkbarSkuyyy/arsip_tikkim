<?php
// Sidebar khusus Super Admin — konteks navigasi terpisah dari sidebar staf
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_nama = isset($_SESSION['user_nama']) ? $_SESSION['user_nama'] : 'Admin';
$user_jabatan = isset($_SESSION['user_jabatan']) ? $_SESSION['user_jabatan'] : 'Super Admin';
$inisial = !empty($user_nama) ? strtoupper(substr($user_nama, 0, 1)) : 'A';
?>

<style>
    /* CSS Sidebar Super Admin — tema gelap ungu-emas, beda dari sidebar staf */
    .sidebar-super { width: 280px; background-color: #1E1B3A; color: #fff; display: flex; flex-direction: column; height: 100vh; flex-shrink: 0; box-shadow: 4px 0 24px rgba(0,0,0,0.15); z-index: 50; overflow: hidden; transition: transform 0.3s ease; }
    .sidebar-super-header { padding: 32px 24px; display: flex; align-items: center; gap: 16px; border-bottom: 1px solid rgba(255,255,255,0.08); flex-shrink: 0; }

    .logo-box { width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; }
    .logo-box img { width: 100%; height: 100%; object-fit: contain; }

    .brand-title { display: flex; flex-direction: column; }
    .brand-main { font-size: 1.6rem; font-weight: 800; color: #ffffff; font-family: 'Outfit', sans-serif; letter-spacing: 0.5px; }
    .brand-sub { font-size: 0.7rem; color: #F5A623; text-transform: none; margin-top: 3px; font-weight: 600; line-height: 1.4; letter-spacing: 0.3px; }

    .super-mode-badge { margin: 16px 24px 0; padding: 8px 14px; background: rgba(245,166,35,0.12); border: 1px solid rgba(245,166,35,0.3); border-radius: 8px; display: flex; align-items: center; gap: 8px; font-size: 0.75rem; font-weight: 700; color: #F5A623; text-transform: uppercase; letter-spacing: 0.5px; flex-shrink: 0; }

    .sidebar-super-nav { flex: 1; padding: 20px 16px; overflow-y: auto; min-height: 0; scrollbar-width: thin; scrollbar-color: rgba(245,166,35,0.35) transparent; }
    .sidebar-super-nav::-webkit-scrollbar { width: 5px; }
    .sidebar-super-nav::-webkit-scrollbar-track { background: transparent; }
    .sidebar-super-nav::-webkit-scrollbar-thumb { background: rgba(245,166,35,0.25); border-radius: 10px; transition: background 0.2s; }
    .sidebar-super-nav:hover::-webkit-scrollbar-thumb { background: rgba(245,166,35,0.5); }
    .sidebar-super-nav::-webkit-scrollbar-thumb:hover { background: rgba(245,166,35,0.7); }
    .nav-menu { list-style: none; display: flex; flex-direction: column; gap: 8px; }
    .nav-section-label { font-size: 0.7rem; color: #6B7280; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 700; padding: 16px 18px 6px; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 14px 18px; border-radius: 10px; color: #9CA3AF; text-decoration: none; font-weight: 500; font-size: 1.05rem; transition: all 0.3s ease; }
    .nav-item .icon svg { width: 20px; height: 20px; }
    .nav-item:hover { background-color: rgba(255,255,255,0.06); color: #fff; }
    .nav-item.active { background-color: rgba(245,166,35,0.15); color: #F5A623; border-left: 4px solid #F5A623; }
    .nav-subitem { padding-left: 34px; font-size: 0.92rem; padding-top: 10px; padding-bottom: 10px; }
    .nav-subitem .icon svg { width: 16px; height: 16px; }

    .sidebar-super-footer { padding: 24px; border-top: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; }
    .user-avatar { width: 36px; height: 36px; background: rgba(245,166,35,0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #F5A623; font-size: 0.9rem; text-transform: uppercase; }
    .btn-logout { color: #EF4444; background: rgba(239, 68, 68, 0.12); width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: 0.2s; }
    .btn-logout:hover { background: #EF4444; color: white; }
    .btn-back-staff { display: flex; align-items: center; gap: 10px; margin: 0 16px 16px; padding: 12px 16px; background: rgba(255,255,255,0.05); border-radius: 10px; color: #D1D5DB; text-decoration: none; font-size: 0.85rem; font-weight: 600; transition: 0.2s; flex-shrink: 0; }
    .btn-back-staff:hover { background: rgba(255,255,255,0.1); color: #fff; }

    /* Hamburger toggle — mobile */
    .nav-toggle { display: none; position: fixed; top: 16px; left: 16px; z-index: 60; width: 44px; height: 44px; border-radius: 10px; background: #1E1B3A; color: #fff; border: 1px solid rgba(245,166,35,0.3); cursor: pointer; align-items: center; justify-content: center; }
    .nav-toggle svg { width: 22px; height: 22px; }
    .sidebar-backdrop { display: none; position: fixed; inset: 0; background: rgba(10, 37, 64, 0.5); z-index: 45; }
    @media (max-width: 900px) {
        .sidebar-super { position: fixed; top: 0; left: 0; bottom: 0; transform: translateX(-100%); }
        .sidebar-super.open { transform: translateX(0); }
        .sidebar-backdrop.show { display: block; }
        .nav-toggle { display: flex; }
    }
</style>

<aside class="sidebar-super" id="appSidebar" aria-label="Menu utama">
    <div class="sidebar-super-header">
        <div class="logo-box">
            <img src="asset/img/logo.png" alt="Logo Imigrasi">
        </div>
        <div class="brand-title">
            <span class="brand-main">SI RAPI</span>
            <span class="brand-sub">Sistem Aplikasi Rekam Arsip<br>Permohonan Imigrasi</span>
            <span class="brand-sub" style="color: #6B7280; text-transform: none; margin-top: 4px; letter-spacing: 0; font-weight: 500;">Super Admin Panel</span>
        </div>
    </div>

    <div class="super-mode-badge">
        <?= icon('crown') ?> Mode Administrator
    </div>

    <nav class="sidebar-super-nav">
        <ul class="nav-menu">
            <li>
                <a href="dashboard_super.php" class="nav-item <?= ($GLOBALS['current_page'] == 'dashboard_super.php') ? 'active' : '' ?>">
                    <?= icon('dashboard') ?> Dashboard Analitik
                </a>
            </li>

            <li class="nav-section-label">Manajemen Data</li>
            <li>
                <a href="master_data.php" class="nav-item <?= ($GLOBALS['current_page'] == 'master_data.php') ? 'active' : '' ?>">
                    <?= icon('database') ?> Master Data
                </a>
            </li>
            <li>
                <a href="data_permohonan.php?jenis=1" class="nav-item <?= ($GLOBALS['current_page'] == 'data_permohonan.php') ? 'active' : '' ?>">
                    <?= icon('folder') ?> Data Permohonan
                </a>
            </li>
            <li>
                <a href="laporan.php" class="nav-item <?= ($GLOBALS['current_page'] == 'laporan.php') ? 'active' : '' ?>">
                    <?= icon('report') ?> Laporan Bulanan
                </a>
            </li>
            <li>
                <a href="import_arsip.php" class="nav-item <?= ($GLOBALS['current_page'] == 'import_arsip.php') ? 'active' : '' ?>">
                    <?= icon('import') ?> Import Arsip Excel
                </a>
            </li>

            <li class="nav-section-label">Pengguna & Keamanan</li>
            <li>
                <a href="kelola_akun.php" class="nav-item <?= ($GLOBALS['current_page'] == 'kelola_akun.php') ? 'active' : '' ?>">
                    <?= icon('users') ?> Kelola Akun
                </a>
            </li>
            <li>
                <a href="register.php" class="nav-item nav-subitem <?= ($GLOBALS['current_page'] == 'register.php') ? 'active' : '' ?>">
                    <?= icon('edit') ?> Tambah Akun
                </a>
            </li>
            <li>
                <a href="audit_trail.php" class="nav-item <?= ($GLOBALS['current_page'] == 'audit_trail.php') ? 'active' : '' ?>">
                    <?= icon('report') ?> Audit Trail
                </a>
            </li>

            <li class="nav-section-label">Sistem</li>
            <li>
                <a href="backup.php" class="nav-item <?= ($GLOBALS['current_page'] == 'backup.php') ? 'active' : '' ?>" data-confirm-link data-confirm-title="Backup Database" data-confirm-msg="Unduh salinan backup database sekarang?" data-confirm-type="info" data-confirm-ok="Unduh Backup">
                    <?= icon('database') ?> Backup Database
                </a>
            </li>
            <li>
                <a href="backup_restore.php" class="nav-item <?= ($GLOBALS['current_page'] == 'backup_restore.php') ? 'active' : '' ?>">
                    <?= icon('upload') ?> Restore Database
                </a>
            </li>
            <li>
                <a href="pengaturan.php" class="nav-item <?= ($GLOBALS['current_page'] == 'pengaturan.php') ? 'active' : '' ?>">
                    <?= icon('settings') ?> Pengaturan
                </a>
            </li>
        </ul>
    </nav>

    <a href="dashboard.php" class="btn-back-staff">
        <?= icon('arrow-left') ?> Kembali ke Tampilan Staf
    </a>

    <div class="sidebar-super-footer">
        <div class="user-info" style="display: flex; align-items: center; gap: 10px;">
            <div class="user-avatar" style="overflow: hidden; padding: 0;">
                <?php if (!empty($_SESSION['user_foto']) && file_exists('asset/img/profile/' . $_SESSION['user_foto'])): ?>
                    <img src="asset/img/profile/<?= htmlspecialchars($_SESSION['user_foto']) ?>" style="width:100%; height:100%; object-fit:cover;">
                <?php else: ?>
                    <?= htmlspecialchars($inisial) ?>
                <?php endif; ?>
            </div>
            <div>
                <div style="font-size: 0.9rem; font-weight: 600;"><?= htmlspecialchars($user_nama) ?></div>
                <div style="font-size: 0.75rem; color: #F5A623;"><?= htmlspecialchars($user_jabatan) ?></div>
            </div>
        </div>
        <a href="logout.php" class="btn-logout" title="Keluar" data-confirm-link data-confirm-title="Keluar" data-confirm-msg="Yakin ingin keluar dari aplikasi?" data-confirm-type="warning" data-confirm-ok="Keluar"><?= icon('logout') ?></a>
    </div>
</aside>

<button class="nav-toggle" id="navToggle" type="button" aria-label="Buka menu" aria-controls="appSidebar" aria-expanded="false">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
</button>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
<script src="asset/js/confirm.js"></script>
<?php include __DIR__ . '/drawer_script.php'; ?>
