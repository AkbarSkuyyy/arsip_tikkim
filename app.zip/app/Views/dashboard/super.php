<?php
/**
 * View: dashboard super admin. Variabel dari DashboardSuperController::index():
 * $total_data, $total_hari_ini, $total_bulan_ini, $total_users, $total_admin,
 * $dok_labels, $dok_data, $ket_labels, $ket_data, $tren_labels, $tren_data,
 * $log_labels, $log_data, $users, $dokumen_list, $logs, $db_size_mb, $total_logs
 */
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Super Admin - SI RAPI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="asset/css/common.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { display: flex; height: 100vh; overflow: hidden; }
        .main-content { flex: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .top-header { height: 88px; background: rgba(244, 247, 250, 0.9); backdrop-filter: blur(10px); display: flex; align-items: center; justify-content: space-between; padding: 0 40px; flex-shrink: 0; position: sticky; top: 0; z-index: 5; border-bottom: 1px solid var(--border-light); }
        .page-title { font-size: 1.5rem; font-weight: 700; color: var(--imigrasi-dark); display: flex; align-items: center; gap: 10px;}
        .content-wrapper { padding: 32px 40px; max-width: 1500px; margin: 0 auto; width: 100%; }
        .stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; margin-bottom: 28px; }
        @media (max-width: 1300px) { .stats-grid { grid-template-columns: repeat(3, 1fr); } }
        .stat-card { background: var(--surface); padding: 22px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border: 1px solid var(--border-light); position: relative; overflow: hidden; }
        .stat-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 4px; background: var(--imigrasi-blue); }
        .stat-card.c-green::before { background: #10B981; }
        .stat-card.c-gold::before { background: var(--imigrasi-gold); }
        .stat-card.c-purple::before { background: #6366F1; }
        .stat-card.c-red::before { background: #EF4444; }
        .stat-title { font-size: 0.78rem; color: var(--text-blue-grey); font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.4px; }
        .stat-value { font-size: 2rem; font-weight: 700; color: var(--imigrasi-dark); line-height: 1; }
        .charts-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 24px; }
        .charts-row-2 { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 24px; }
        @media (max-width: 1200px) { .charts-row-3, .charts-row-2 { grid-template-columns: 1fr; } }
        .card-container { background: var(--surface); padding: 24px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border: 1px solid var(--border-light); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .card-title { font-size: 1.05rem; font-weight: 700; color: var(--imigrasi-dark); margin: 0; }
        .canvas-container { position: relative; height: 240px; width: 100%; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { color: var(--text-blue-grey); font-weight: 600; font-size: 0.78rem; padding: 14px; border-bottom: 2px solid var(--border-light); text-transform: uppercase; text-align: left; }
        td { padding: 14px; border-bottom: 1px solid var(--border-light); font-size: 0.92rem; font-weight: 500; }
        .btn-add { background: var(--imigrasi-gold); color: var(--imigrasi-dark); padding: 9px 18px; border-radius: 8px; font-weight: 700; text-decoration: none; font-size: 0.85rem; transition: 0.2s; display: inline-flex; align-items: center; gap: 6px;}
        .btn-add:hover { opacity: 0.9; transform: translateY(-2px); }
        .btn-backup, .btn-restore { color: white; padding: 9px 18px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-right: 8px; display: inline-flex; align-items: center; gap: 6px; font-size: 0.85rem;}
        .btn-backup { background: #10B981; }
        .btn-restore { background: #6366F1; }
        .log-item { margin-bottom: 14px; padding-bottom: 10px; border-bottom: 1px solid var(--border-light); }
        .log-item:last-child { border-bottom: none; margin-bottom: 0; }
        .log-aksi { font-weight: 600; font-size: 0.87rem; color: var(--imigrasi-blue); }
        .log-meta { font-size: 0.78rem; color: var(--text-blue-grey); margin-top: 3px; }
        .btn-edit, .btn-delete, .btn-reset { padding: 7px 12px; border-radius: 8px; font-size: 0.78rem; font-weight: 600; text-decoration: none; transition: 0.2s; display: inline-flex; align-items: center; gap: 6px; border: 1px solid transparent; cursor: pointer; white-space: nowrap; line-height: 1; }
        .btn-edit { background: rgba(59, 130, 246, 0.1); color: #2563EB; border-color: rgba(59, 130, 246, 0.25); }
        .btn-edit:hover { background: #3B82F6; color: #fff; }
        .btn-reset { background: rgba(99, 102, 241, 0.1); color: #4F46E5; border-color: rgba(99, 102, 241, 0.25); }
        .btn-reset:hover { background: #6366F1; color: #fff; }
        .btn-delete { background: rgba(239, 68, 68, 0.1); color: #DC2626; border-color: rgba(239, 68, 68, 0.25); }
        .btn-delete:hover { background: #EF4444; color: #fff; }
        .btn-edit .icon svg, .btn-reset .icon svg, .btn-delete .icon svg { width: 14px; height: 14px; }
        .aksi-group { display: flex; gap: 6px; align-items: center; flex-wrap: nowrap; }
        .avatar-cell { display: flex; align-items: center; gap: 10px; }
        .avatar { width: 36px; height: 36px; border-radius: 50%; background: var(--imigrasi-blue); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.85rem; flex-shrink: 0; }
        .role-badge { padding: 4px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; }
        .role-superadmin { background: rgba(245,166,35,0.15); color: #B45309; }
        .role-admin { background: rgba(245,166,35,0.12); color: #D48806; }
        .role-user { background: rgba(11,66,123,0.1); color: var(--imigrasi-blue); }
        .role-viewer { background: rgba(16,185,129,0.12); color: #059669; }
        .akses-chip { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 0.72rem; font-weight: 600; background: rgba(99,102,241,0.12); color: #4F46E5; margin: 1px; }
        .sys-info-list { display: flex; flex-direction: column; gap: 14px; }
        .sys-info-item { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid var(--border-light); }
        .sys-info-item:last-child { border-bottom: none; padding-bottom: 0; }
        .sys-info-label { font-size: 0.85rem; color: var(--text-blue-grey); font-weight: 500; }
        .sys-info-value { font-size: 0.9rem; font-weight: 700; color: var(--imigrasi-dark); }
        .live-badge { font-size: 0.75rem; font-weight: 700; color: #059669; background: rgba(16,185,129,0.12); border: 1px solid rgba(16,185,129,0.3); padding: 4px 12px; border-radius: 20px; margin-left: 12px; display: inline-flex; align-items: center; gap: 6px; }
        .live-badge::before { content: ''; width: 7px; height: 7px; border-radius: 50%; background: #10B981; animation: rt-pulse 2s infinite; }
        @keyframes rt-pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }

        /* Responsive mobile */
        @media (max-width: 900px) {
            .content-wrapper { padding: 16px; }
            .card-container { padding: 16px; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
            .top-header { padding: 0 16px; height: auto; min-height: 64px; }
            .page-title { font-size: 1.15rem; }
            .canvas-container { height: 200px; }
            .card-header { flex-direction: column; align-items: stretch; gap: 10px; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../layouts/nav.php'; ?>
    <main class="main-content">
        <header class="top-header">
            <h1 class="page-title"><?= icon('crown') ?> Dashboard Super Admin <span class="live-badge">Live · <span data-rt-time>--:--:--</span></span></h1>
        </header>
        <div class="content-wrapper">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-title">Total Permohonan</div>
                    <div class="stat-value" data-rt="total"><?= (int)$total_data ?></div>
                </div>
                <div class="stat-card c-green">
                    <div class="stat-title">Input Hari Ini</div>
                    <div class="stat-value" data-rt="today"><?= (int)$total_hari_ini ?></div>
                </div>
                <div class="stat-card c-gold">
                    <div class="stat-title">Input Bulan Ini</div>
                    <div class="stat-value" data-rt="bulan_ini"><?= (int)$total_bulan_ini ?></div>
                </div>
                <div class="stat-card c-purple">
                    <div class="stat-title">Total Pengguna</div>
                    <div class="stat-value" data-rt="users"><?= (int)$total_users ?></div>
                </div>
                <div class="stat-card c-red">
                    <div class="stat-title">Akun Admin</div>
                    <div class="stat-value" data-rt="admin"><?= (int)$total_admin ?></div>
                </div>
            </div>

            <div class="charts-row-3">
                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Proporsi Jenis Dokumen</h2>
                    <div class="canvas-container"><canvas id="chartDokumen"></canvas></div>
                </div>
                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Proporsi Keterangan</h2>
                    <div class="canvas-container"><canvas id="chartKeterangan"></canvas></div>
                    <table class="proporsi-list">
                        <thead><tr><th>KETERANGAN</th><th>JUMLAH</th><th>PROPORSI</th></tr></thead>
                        <tbody>
                            <?php foreach ($ket_proporsi as $k): ?>
                            <tr>
                                <td><?= htmlspecialchars($k['nama']) ?></td>
                                <td><?= (int)$k['jumlah'] ?></td>
                                <td><?= number_format((float)$k['persen'], 1, ',', '.') ?>%</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?= (int)$ket_total ?></strong></td>
                                <td><strong>100%</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Komposisi Role Pengguna</h2>
                    <div class="canvas-container"><canvas id="chartRole"></canvas></div>
                </div>
            </div>

            <div class="charts-row-2">
                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Tren Permohonan Bulanan (12 Bulan)</h2>
                    <div class="canvas-container" style="height: 260px;"><canvas id="chartTren"></canvas></div>
                </div>
                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Info Sistem</h2>
                    <div class="sys-info-list">
                        <div class="sys-info-item"><span class="sys-info-label">Ukuran Database</span><span class="sys-info-value"><?= $db_size_mb ?> MB</span></div>
                        <div class="sys-info-item"><span class="sys-info-label">Total Log Aktivitas</span><span class="sys-info-value"><?= (int)$total_logs ?></span></div>
                        <div class="sys-info-item"><span class="sys-info-label">PHP Version</span><span class="sys-info-value"><?= PHP_VERSION ?></span></div>
                        <div class="sys-info-item"><span class="sys-info-label">Server Time</span><span class="sys-info-value"><?= date('d/m/Y H:i') ?></span></div>
                    </div>
                </div>
            </div>

            <div class="card-container" style="margin-bottom: 24px;">
                <h2 class="card-title" style="margin-bottom: 20px;">Aktivitas Log (14 Hari Terakhir)</h2>
                <div class="canvas-container" style="height: 220px;"><canvas id="chartLogAktivitas"></canvas></div>
            </div>

            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
                <div class="card-container">
                    <div class="card-header">
                        <h2 class="card-title">Daftar Pengguna Sistem (<?= count($users) ?>)</h2>
                        <div style="display:flex; gap:8px; flex-wrap:wrap;">
                            <a href="backup.php" class="btn-backup" data-confirm-link data-confirm-title="Backup Database" data-confirm-msg="Unduh salinan backup database sekarang?" data-confirm-type="info" data-confirm-ok="Unduh Backup"><?= icon('database') ?> Backup DB</a>
                            <a href="backup_restore.php" class="btn-restore"><?= icon('upload') ?> Restore DB</a>
                            <a href="register.php" class="btn-add"><?= icon('users') ?> Tambah Akun</a>
                        </div>
                    </div>
                    <?php $dok_map = []; foreach ($dokumen_list as $d) $dok_map[$d['kode']] = $d['nama']; ?>
                    <div class="table-scroll" role="region" aria-label="Daftar pengguna sistem, geser untuk melihat kolom lainnya" tabindex="0">
                    <table>
                        <thead><tr><th>NAMA</th><th>USERNAME</th><th>JABATAN</th><th>ROLE</th><th>AKSES DOKUMEN</th><th>AKSI</th></tr></thead>
                        <tbody>
                            <?php foreach ($users as $usr): ?>
                            <tr>
                                <td>
                                    <div class="avatar-cell">
                                        <div class="avatar"><?= htmlspecialchars(strtoupper(substr((string)$usr['nama'], 0, 1))) ?></div>
                                        <span style="font-weight:700; color:var(--imigrasi-dark);"><?= htmlspecialchars($usr['nama']) ?></span>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($usr['username']) ?></td>
                                <td><?= htmlspecialchars($usr['jabatan']) ?></td>
                                <td><span class="role-badge role-<?= htmlspecialchars($usr['role']) ?>"><?= htmlspecialchars(UserController::roleLabel($usr['role'])) ?></span></td>
                                <td>
                                    <?php if (($usr['akses_dokumen'] ?? '*') === '*'): ?>
                                        <span class="akses-chip" style="background: rgba(245,166,35,0.15); color:#D48806;">Semua</span>
                                    <?php else: ?>
                                        <?php $akses_arr = array_filter(array_map('trim', explode(',', (string)($usr['akses_dokumen'] ?? ''))), 'strlen'); ?>
                                        <?php if (empty($akses_arr)): ?>
                                            <span class="akses-chip">-</span>
                                        <?php else: ?>
                                            <?php foreach ($akses_arr as $k): ?>
                                                <span class="akses-chip"><?= htmlspecialchars($dok_map[$k] ?? $k) ?></span>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="aksi-group">
                                        <a href="edit_user.php?id=<?= (int)$usr['id'] ?>" class="btn-edit" title="Edit akun"><?= icon('edit') ?> Edit</a>
                                        <a href="reset_password.php?id=<?= (int)$usr['id'] ?>" class="btn-reset" title="Reset password"><?= icon('key') ?> Reset</a>
                                        <?php if ((int)$usr['id'] !== Auth::userId()): ?>
                                        <form method="POST" action="hapus_user.php" style="display:inline;" data-confirm data-confirm-title="Hapus Akun" data-confirm-msg="Yakin ingin menghapus akun ini? Tindakan tidak bisa dibatalkan.">
                                            <input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
                                            <?= Csrf::field() ?>
                                            <button type="submit" class="btn-delete" title="Hapus akun"><?= icon('trash') ?> Hapus</button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                </div>

                <div class="card-container">
                    <h2 class="card-title" style="margin-bottom: 20px;">Log Aktivitas Terbaru</h2>
                    <div>
                        <?php foreach ($logs as $log): ?>
                        <div class="log-item">
                            <div class="log-aksi"><?= htmlspecialchars($log['aksi']) ?></div>
                            <div class="log-meta"><?= htmlspecialchars($log['waktu']) ?> | <?= htmlspecialchars($log['user']) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        const chartFont = { family: 'Inter' };

        new Chart(document.getElementById('chartDokumen').getContext('2d'), {
            type: 'doughnut',
            data: { labels: <?= json_encode($dok_labels) ?>, datasets: [{ data: <?= json_encode($dok_data) ?>, backgroundColor: ['#0B427B', '#F5A623', '#10B981', '#6366F1', '#EF4444', '#8B5CF6'], borderWidth: 0, hoverOffset: 4 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { position: 'bottom', labels: { font: chartFont, boxWidth: 12, padding: 12 } } } }
        });

        new Chart(document.getElementById('chartKeterangan').getContext('2d'), {
            type: 'pie',
            data: { labels: <?= json_encode($ket_labels) ?>, datasets: [{ data: <?= json_encode($ket_data) ?>, backgroundColor: ['#10B981', '#F5A623', '#0B427B', '#EF4444'], borderWidth: 0, hoverOffset: 4 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: chartFont, boxWidth: 12, padding: 12 } } } }
        });

        new Chart(document.getElementById('chartRole').getContext('2d'), {
            type: 'doughnut',
            data: { labels: ['Super Admin', 'Admin', 'Petugas', 'Viewer'], datasets: [{ data: [<?= (int)$role_breakdown['superadmin'] ?>, <?= (int)$role_breakdown['admin'] ?>, <?= (int)$role_breakdown['user'] ?>, <?= (int)$role_breakdown['viewer'] ?>], backgroundColor: ['#B45309', '#F5A623', '#0B427B', '#10B981'], borderWidth: 0, hoverOffset: 4 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { position: 'bottom', labels: { font: chartFont, boxWidth: 12, padding: 12 } } } }
        });

        new Chart(document.getElementById('chartTren').getContext('2d'), {
            type: 'line',
            data: { labels: <?= json_encode($tren_labels) ?>, datasets: [{ label: 'Jumlah Permohonan', data: <?= json_encode($tren_data) ?>, borderColor: '#0B427B', backgroundColor: 'rgba(11,66,123,0.1)', fill: true, tension: 0.3, borderWidth: 2, pointBackgroundColor: '#F5A623', pointRadius: 4 }] },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, border: { display: false }, ticks: { font: chartFont } }, x: { grid: { display: false }, ticks: { font: chartFont } } }
            }
        });

        new Chart(document.getElementById('chartLogAktivitas').getContext('2d'), {
            type: 'bar',
            data: { labels: <?= json_encode($log_labels) ?>, datasets: [{ label: 'Aktivitas', data: <?= json_encode($log_data) ?>, backgroundColor: '#6366F1', borderRadius: 6, borderWidth: 0 }] },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1, font: chartFont }, border: { display: false } }, x: { grid: { display: false }, ticks: { font: chartFont } } }
            }
        });
    </script>
    <script src="asset/js/realtime.js"></script>
    <script src="asset/js/confirm.js"></script>
</body>
</html>
