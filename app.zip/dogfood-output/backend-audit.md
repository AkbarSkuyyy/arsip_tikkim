# Audit backend SI RAPI — read-only

## Lingkup dan batas

Seluruh controller, model, core, routes, bootstrap, front controller, aturan `.htaccess`, serta view ekspor dibaca. Tidak login, tidak menjalankan controller terhadap DB, tidak membaca `config.php`, `.env`, dump SQL, atau berkas kredensial. Tidak mengubah aplikasi/DB; hanya laporan ini ditulis. Pengujian HTTP terautentikasi terblokir karena izin login tidak tersedia. Responsivitas bukan cakupan audit backend ini.

## Bukti eksekusi nyata

- PHP CLI `C:/xampp/php/php.exe`: **8.3.33**.
- Inventaris rekursif: **49 PHP**. Lint **47**, lulus **47**, gagal **0**. `app/config.php` dan `app/config.example.php` sengaja dikecualikan agar batas larangan membaca konfigurasi tetap ketat. Jadi bukan klaim seluruh 49 file sudah dilint.
- Lint memakai subprocess `php.exe -l <path>` untuk setiap PHP non-konfigurasi; tidak menjalankan bootstrap.
- Probe CLI hanya memuat `app/Core/Helpers.php` dan `app/Controllers/AuthController.php`, tanpa session/login/DB:
  - `norm_tgl_lahir('2024-02-29')` menghasilkan `2024-02-29`.
  - `norm_tgl_lahir('2024oops-02-29')` menghasilkan `2024-02-29` (**input rusak diterima**).
  - `norm_tgl_lahir('2024-1x-2y')` menghasilkan `2024-01-02` (**input rusak diterima**).
  - `norm_tgl_lahir('2024-02-30')` menghasilkan `null` (tanggal kalender invalid ditolak).
  - `norm_tgl_lahir([])` menghasilkan `TypeError`.
  - `fopen('', 'r')` menghasilkan `ValueError`.
  - Reflection memanggil `AuthController::clientIp()` dengan REMOTE_ADDR tetap `127.0.0.1`. Mengubah X-Forwarded-For dari `198.51.100.10` ke `203.0.113.20` mengubah hasil clientIp persis mengikuti header.

Probe ini membuktikan perilaku fungsi lokal, bukan keberhasilan eksploitasi HTTP atau perubahan database.

## Temuan prioritas

### B01 — Tinggi: update arsip tidak memeriksa kepemilikan record lama

**Bukti analisis kode:** `app/Controllers/PermohonanController.php:96-107`; `app/Models/Permohonan.php:27-35`.

Update mengambil `id_permohonan` dari POST, lalu hanya memeriksa akses terhadap **dokumen baru yang dikirim**. Tidak mengambil record lama untuk memeriksa jenis dokumennya. Model menjalankan `UPDATE ... WHERE id = ?` tanpa scope akses. Petugas ber-CSRF valid dapat mengirim ID arsip jenis lain sambil mengirim kode dokumen yang diizinkan baginya. Record jenis lain dapat tertimpa dan dipindahkan jenisnya. Bandingkan delete yang sudah membaca record lama pada controller baris 49-50.

**Prasyarat:** akun petugas dan record lintas jenis; bila deployment hanya punya satu jenis, dampak lintas jenis masih laten. Belum diuji lewat POST.

**Perbaikan:** baca record lama, cek akses jenis lama dan baru; scope UPDATE atau transaksi untuk menjaga pemeriksaan konsisten.

### B02 — Tinggi: kondisi pelindung superadmin terakhir terbalik

**Bukti analisis kode:** `app/Controllers/UserController.php:108-117,190-194`.

Penolakan berjalan saat `$role === 'superadmin' && isLastSuperadmin($id)`. `$role` merupakan role tujuan. Menurunkan satu-satunya superadmin ke `user`, `admin`, atau `viewer` justru melewati guard; mempertahankan role superadmin dapat ditolak. Setelah sesi lama berakhir, pengelolaan sistem berpotensi terkunci.

**Perbaikan:** periksa role record lama superadmin, role tujuan bukan superadmin, serta tidak ada superadmin lain; lindungi terhadap race. Belum melakukan perubahan akun.

### B03 — Tinggi: pembatasan percobaan login mempercayai header IP pengguna

**Bukti eksekusi lokal + analisis kode:** `app/Controllers/AuthController.php:9-15,67-71,104-106`.

`clientIp()` menerima X-Forwarded-For tanpa whitelist reverse proxy. Probe membuktikan hasil berubah hanya dengan mengubah header. Karena throttle memakai hasil tersebut sebagai kunci, klien yang dapat mengirim header langsung dapat mengganti kunci throttle. Dampak deployment bergantung apakah proxy menimpa header secara tepercaya; tidak diverifikasi di hosting.

**Perbaikan:** gunakan REMOTE_ADDR kecuali request berasal dari proxy tepercaya; validasi IP dan chain proxy. Tambah pembatasan per akun. Jangan mengikuti saran proxy-aware yang mempercayai header secara umum.

### B04 — Tinggi: pencabutan akun/role/password tidak mencabut sesi aktif

**Bukti analisis kode:** `app/Core/Auth.php:13-16,24-45,49-56`; `app/Controllers/AuthController.php:83-91`; `app/Controllers/UserController.php:117,149,178`.

Identitas, role, dan akses disalin saat login. Guard selanjutnya hanya memeriksa session dan idle timeout, tanpa memvalidasi keberadaan akun, role terbaru, atau versi sesi. Akun yang sudah dihapus atau superadmin yang diturunkan tetap memakai hak lama selama sesi aktif. Reset password juga tidak membatalkan sesi lain. Aktivitas rutin terus memperbarui idle timer.

**Perbaikan:** session version/revocation server-side dan pemeriksaan akun aktif/hak terbaru. Belum diuji dengan sesi nyata.

### B05 — Sedang: session ID tidak diregenerasi setelah login

**Bukti analisis kode:** `app/Controllers/AuthController.php:81-97`; `app/Core/Session.php:7-11`.

Login sukses langsung menulis atribut autentikasi tanpa `session_regenerate_id(true)`. Ini membuka risiko session fixation bila penyerang berhasil menanam SID awal. Cookie hardening juga tidak ditetapkan pada kode session; nilai efektif php.ini belum diperiksa, sehingga tidak diklaim pasti tidak aman.

**Perbaikan:** regenerasi SID setelah autentikasi/perubahan hak; cookie HttpOnly, Secure pada HTTPS, SameSite, dan strict mode.

### B06 — Sedang: scope dashboard/laporan/ekspor fail-open untuk akses petugas kosong atau '*'

**Bukti analisis kode:** `app/Controllers/ExportController.php:19-25`; `app/Controllers/LaporanController.php:15-21`; `app/Controllers/DashboardController.php:14-26`; `app/Core/Auth.php:147-152`; `app/Models/Permohonan.php:355-364`.

`aksesDokumenTunggal()` menghasilkan string kosong untuk akses kosong/'*'. Ketiga controller membiarkan filter `[]`, yang berarti semua jenis. Berbeda dengan `PermohonanController.php:39-41` dan `RealtimeController.php:18-20` yang memakai sentinel `__none__`.

`UserController.php:35-39,69-75,109-117` hanya memeriksa akses petugas bukan kosong; tidak memastikan tepat satu kode aktif. Nilai '*' atau CSV dapat disimpan lewat POST superadmin. Tidak ada bukti akun nyata memiliki kondisi tersebut.

**Perbaikan:** satu resolver scope fail-closed untuk seluruh endpoint; whitelist kode aktif dan tepat satu kode petugas.

### B07 — Sedang: validasi tanggal dan tipe input tidak ketat

**Bukti eksekusi lokal + analisis kode:** `app/Core/Helpers.php:8-18`; `app/Controllers/PermohonanController.php:154-166`; `app/Controllers/AuthController.php:76-81`; `app/Controllers/LaporanController.php:11-13,21`.

Normalizer mengubah potongan tanggal menjadi integer sebelum memeriksa format. Input seperti `2024oops-02-29` dan `2024-1x-2y` terbukti diterima. Input array tanggal menghasilkan TypeError; beberapa `trim($_POST/$_GET...)` juga tidak memeriksa scalar. Tanggal input rusak diam-diam diganti hari ini pada controller baris 163, sehingga kesalahan pengguna tidak terlihat. Rentang tanggal laporan tidak divalidasi atau dicek urutannya.

**Perbaikan:** tolak non-string, validasi format tanggal exact, kalender dan rentang bisnis; tampilkan error field, jangan mengganti input invalid diam-diam. Uji HTTP input rusak belum dijalankan.

### B08 — Sedang: impor CSV melewati validasi utama dan rawan gagal parsial

**Bukti analisis kode:** `app/Controllers/ImportController.php:17-26,32-56`; `app/Models/Permohonan.php:15-24`.

- `bulan_arsip` langsung dirangkai menjadi tanggal tanpa range 1–12.
- Upload error/ukuran tidak diperiksa sebelum `fopen`; tmp_name kosong dapat menghasilkan ValueError, sesuai probe PHP lokal.
- Header dilewati tanpa validasi skema; parser membatasi pembacaan 1000 byte, rawan memecah record panjang.
- Jenis dokumen, jenis kelamin, keterangan, dan panjang field tidak divalidasi; model tidak menambah validasi tersebut.
- Import tidak memanggil alokasi lokasi otomatis dan tidak mengirim lokasi; model menyimpan default loker 0/rak kosong/kotak kosong.
- Tidak ada transaksi atau catch exception per baris. Jika DB menolak baris di tengah, baris sebelumnya dapat sudah tersimpan tanpa laporan akhir yang lengkap. Perilaku error DB bergantung konfigurasi MySQL/mysqli; DB tidak disentuh.

**Perbaikan:** validasi upload, header, seluruh field dan referensi; preview/validasi sebelum commit; kebijakan transaksi/partial-import eksplisit dan laporan per baris; konsistenkan alokasi lokasi.

### B09 — Sedang: backup mengubah SQL NULL menjadi string kosong

**Bukti analisis kode:** `app/Controllers/BackupController.php:39-46`.

Untuk nilai null, serializer menetapkan `$val = ''` lalu selalu mengapit nilai dengan tanda petik ganda. Hasil dump memakai `""`, bukan `NULL`. Restore tidak mempertahankan data nullable; untuk kolom tanggal/numerik dapat error atau coercion. Dump juga bergantung mode SQL karena literal memakai tanda petik ganda/addslashes.

**Perbaikan:** serializer SQL benar atau alat backup standar; NULL harus literal tanpa kutip; uji round-trip di DB uji. Tidak mengunduh atau membaca dump nyata.

### B10 — Sedang: restore gagal dapat meninggalkan database setengah dipulihkan

**Bukti analisis kode:** `app/Controllers/BackupController.php:60-85`.

Isi upload langsung dijalankan dengan `mysqli_multi_query`; tidak ada staging, pemulihan otomatis, atau pemeriksaan upload. Statement awal dapat berhasil sebelum statement berikut gagal. DDL tidak dapat dianggap aman hanya dengan membungkus transaction. Pada mode mysqli strict, exception juga dapat melewati pesan error normal.

**Perbaikan:** proses restore maintenance terkontrol, backup sebelum restore, validasi upload, staging, dan prosedur rollback operasional. Arbitrary SQL pada endpoint ini merupakan kemampuan superadmin yang disengaja, bukan klaim SQL injection anonim.

### B11 — Sedang: update lokasi dan master reference tidak tervalidasi

**Bukti analisis kode:** `app/Controllers/PermohonanController.php:100-107,160-166`; `app/Core/Auth.php:156-161`; `app/Models/Permohonan.php:27-35`.

Update menerima loker_id, rak, kotak tanpa cek loker aktif, kapasitas rak/urutan, atau slot terisi. Admin juga selalu lolos `canAksesDokumen`, meskipun kode dokumen kosong/tidak terdaftar. Keterangan bebas; jenis kelamin selain P diam-diam menjadi L. Validasi dropdown browser tidak melindungi POST buatan.

**Perbaikan:** validasi referensi aktif/enum/panjang dan lokasi server-side. Constraint DB tidak diperiksa, sehingga efek penyimpanan invalid belum dibuktikan.

## Catatan tambahan dan hosting

- **Upload profil:** `app/Controllers/PengaturanController.php:31-45` memeriksa ekstensi saja, tanpa verifikasi MIME/decode gambar, batas ukuran aplikasi, atau error upload. Bukan bukti RCE; handler Apache/MIME dan batas php.ini belum diperiksa. Re-encode gambar, batasi ukuran/dimensi, gunakan direktori non-executable.
- **Identitas login:** `app/Controllers/PengaturanController.php:19-26` hanya memeriksa username, bukan email unik/format/wajib. `app/Models/User.php:15-18` mencari username OR email LIMIT 1. Email duplikat atau benturan username-email dapat membuat login ambigu; DB constraint belum diperiksa. Registrasi `UserController.php:63-79` juga tidak memvalidasi email, field wajib, dan panjang selain password minimum.
- **Ekspor:** `app/Views/laporan/export_excel.php:8-10,50-52` merender pengaturan instansi tanpa escaping HTML. Field arsip menggunakan htmlspecialchars tetapi tidak memaksa tipe text spreadsheet (`:33-38`); perilaku formula/import spreadsheet perlu diuji di aplikasi spreadsheet, belum terbukti. Jangan menyebutnya XSS/formula execution terkonfirmasi.
- **Ekspor tidak mengikuti pencarian:** `app/Controllers/ExportController.php:25` selalu mengirim keyword kosong, sedangkan laporan memakai `$cari` pada `LaporanController.php:21`. Ekspor dari laporan terfilter berpotensi berisi lebih banyak data; alur link UI belum diaudit penuh.
- **Konkurensi lokasi:** `app/Models/Permohonan.php:248-268` mencari slot kosong, terpisah dari insert pada `PermohonanController.php:72-85`, tanpa lock/transaksi aplikasi. Dua request dapat memilih slot sama; constraint DB belum diketahui, sehingga duplikasi nyata belum dibuktikan.
- **Logout GET:** `app/routes.php:8`, `app/Controllers/AuthController.php:115-119` tidak memerlukan POST/CSRF. Navigasi lintas situs dapat menyebabkan logout paksa, bukan pengambilalihan akun.
- **Enumerasi akun:** pesan login membedakan username tidak ada dan password salah (`AuthController.php:98-102`). Gunakan pesan generik.
- **Hosting:** `.htaccess:2` menonaktifkan listing dan `app/.htaccess:3-9` menolak akses langsung app. Ini kontrol positif pada kode, **belum verifikasi HTTP 403**. Keefektifan bergantung Apache AllowOverride/modul; server Nginx mengabaikan `.htaccess`.
- Root rewrite `.htaccess:10-12` melewatkan file yang benar-benar ada. Tidak ada aturan root khusus untuk `.env`, dump SQL, atau laporan audit. Keberadaan/keterbukaan file sensitif tidak diuji. **Jangan deploy `dogfood-output/` ke web publik**; laporan ini menjelaskan kelemahan internal.
- `app/bootstrap.php:31` membuka koneksi DB sebelum guard login; `app/Core/Database.php:23-25,38-45` tidak menyediakan penanganan exception terpusat. Kegagalan DB dapat merusak halaman login dan mengungkap error bila display_errors aktif. Nilai produksi belum diperiksa. Driver juga tidak menetapkan charset eksplisit; rekomendasi utf8mb4 dan error logging privat.

## Kontrol positif yang terlihat

Prepared statements dipakai untuk parameter data/query; router memakai daftar route tetap, bukan include path langsung dari input. Mutasi utama punya Csrf::verify dengan hash_equals. Viewer ditolak pada POST arsip. Menu akun/master/restore memakai requireSuperadmin. Validasi kalender `checkdate` menolak tanggal mustahil. Semua PHP non-konfigurasi lulus syntax check.

## Tindak lanjut aman

1. Dahulukan otorisasi record lama, guard superadmin terakhir, trusted proxy throttle, dan revokasi sesi.
2. Satukan validasi scalar/tanggal/master reference, resolver scope, dan jalur impor.
3. Uji regresi pada DB uji dengan akun per role setelah izin tersedia; jangan memakai produksi untuk uji mutasi/restore.
4. Verifikasi HTTP hosting dan kebijakan session; audit responsivitas terpisah.

**Kesimpulan:** lint bersih tidak berarti validasi/keamanan lulus. Temuan kode konkret tersedia; hanya normalizer tanggal, pemilihan IP throttle, dan perilaku exception PHP lokal yang diuji eksekusi. CRUD/login/import/export/backup/restore end-to-end belum dinyatakan lulus.
